# ISR Backend APIs

Base URL (dev): `http://localhost:4000`

---

## Health

### `GET /health`

Liveness check.

**Response** `200 OK`
```
OK
```

---

## Prayer Times

All prayer times endpoints proxy the [Al-Adhan API](https://aladhan.com/prayer-times-api) for **Melbourne, Australia** using calculation method **3 (Muslim World League)**.

Returned timings: `Fajr`, `Sunrise`, `Dhuhr`, `Asr`, `Sunset`, `Maghrib`, `Isha`.

---

### `GET /api/prayer-times`

Today's prayer times.

**Response** `200 OK`
```json
{
  "data": {
    "timings": {
      "Fajr": "06:01",
      "Sunrise": "07:35",
      "Dhuhr": "12:21",
      "Asr": "14:50",
      "Sunset": "17:08",
      "Maghrib": "17:08",
      "Isha": "18:37"
    },
    "date": {
      "readable": "19 Jun 2026",
      "timestamp": "1781816400",
      "hijri": {
        "date": "04-01-1448",
        "day": "4",
        "weekday": { "en": "Al Juma'a" },
        "month": { "number": 1, "en": "Muḥarram" },
        "year": "1448"
      },
      "gregorian": {
        "date": "19-06-2026",
        "weekday": { "en": "Friday" },
        "month": { "number": 6, "en": "June" },
        "year": "2026"
      }
    },
    "meta": {
      "timezone": "Australia/Melbourne",
      "method": { "id": 3, "name": "Muslim World League" }
    }
  }
}
```

**Error** `502 Bad Gateway` — upstream Al-Adhan API unreachable.

---

### `GET /api/prayer-times/:date`

Prayer times for a specific date.

**Path parameter**

| Parameter | Format | Example |
|---|---|---|
| `date` | `DD-MM-YYYY` | `19-06-2026` |

**Response** `200 OK` — same shape as `GET /api/prayer-times`.

**Errors**

| Status | Condition |
|---|---|
| `400` | `date` is not in `DD-MM-YYYY` format |
| `502` | Upstream Al-Adhan API unreachable |

```json
{ "error": "Date must be in DD-MM-YYYY format" }
```

---

### `GET /api/prayer-times/calendar`

Full monthly prayer times calendar.

**Query parameters**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `year` | integer | current year | 4-digit year, e.g. `2026` |
| `month` | integer | current month | 1–12 |

**Example**
```
GET /api/prayer-times/calendar?year=2026&month=6
```

**Response** `200 OK`
```json
{
  "data": [
    {
      "timings": { "Fajr": "...", "Sunrise": "...", "Dhuhr": "...", "Asr": "...", "Sunset": "...", "Maghrib": "...", "Isha": "..." },
      "date": { ... },
      "meta": { ... }
    }
    // one entry per day (28–31 items)
  ]
}
```

**Error** `502 Bad Gateway` — upstream Al-Adhan API unreachable.

---

## Auth

Admin authentication via Supabase. Protected routes require `Authorization: Bearer <access_token>` and `app_metadata.role === "admin"`.

---

### `POST /api/auth/signin`

Sign in with email and password.

**Request body**

| Field | Type | Required |
|---|---|---|
| `email` | string | yes |
| `password` | string | yes |

**Response** `200 OK`
```json
{
  "data": {
    "user": {
      "id": "...",
      "email": "admin@isr.org",
      "app_metadata": { "role": "admin" }
    },
    "session": {
      "access_token": "...",
      "refresh_token": "...",
      "expires_in": 3600,
      "token_type": "bearer"
    }
  }
}
```

Returns the Supabase auth payload wrapped in `{ "data": ... }`. Use `data.session.access_token` for protected requests.

**Error** `400 Bad Request`

```json
{ "error": "Invalid login credentials" }
```

---

### `GET /api/auth/me`

Return the authenticated admin user.

**Headers**

| Header | Value |
|---|---|
| `Authorization` | `Bearer <access_token>` |

**Response** `200 OK`
```json
{
  "data": {
    "user": {
      "id": "...",
      "email": "admin@isr.org",
      "app_metadata": { "role": "admin" }
    }
  }
}
```

**Errors**

| Status | Body |
|---|---|
| `401` | `{ "error": "Unauthorized" }` — missing, malformed, or invalid token |
| `403` | `{ "error": "Forbidden" }` — valid token but user is not an admin |

---

## Weather

Current weather for Melbourne via [WeatherAPI](https://www.weatherapi.com/).

---

### `GET /api/weather`

Returns current weather conditions for Melbourne, Australia.

**Response** `200 OK`
```json
{
  "data": {
    "location": {
      "name": "Melbourne",
      "region": "Victoria",
      "country": "Australia",
      "localtime": "2026-07-24 14:30"
    },
    "current": {
      "temp_c": 12.1,
      "feelslike_c": 9.8,
      "humidity": 72,
      "wind_kph": 20.5,
      "wind_dir": "SW",
      "condition": {
        "text": "Partly cloudy",
        "icon": "//cdn.weatherapi.com/weather/64x64/day/116.png",
        "code": 1003
      },
      "uv": 2.0,
      "vis_km": 10.0,
      "precip_mm": 0.0
    }
  }
}
```

**Errors**

| Status | Body |
|---|---|
| `500` | `{ "error": "Weather API key not configured" }` — `WEATHER_API_KEY` missing from environment |
| `502` | `{ "error": "Invalid Weather API key" }` — key rejected by WeatherAPI |
| `502` | `{ "error": "Weather API responded with <status>" }` — other upstream error |
| `502` | `{ "error": "Failed to fetch weather data" }` — network failure |

---

## Events

Event data is stored in Postgres (via Prisma) and event poster images are stored in Supabase
Storage. Read endpoints are **public**; create/update/delete are **admin-only** (require
`Authorization: Bearer <access_token>` with `app_metadata.role === "admin"`).

An event has the shape:

```json
{
  "id": 1,
  "name": "Eid Dinner",
  "date": "2026-08-01T18:00:00.000Z",
  "endDate": null,
  "recurrenceFrequency": null,
  "recurrenceInterval": null,
  "recurrenceEndDate": null,
  "imageUrl": "https://<project>.supabase.co/storage/v1/object/public/event-images/...",
  "description": "Community Eid celebration dinner.",
  "ticketUrl": "https://tickets.example.com/eid",
  "isMultiDay": false,
  "isRecurring": false,
  "nextOccurrence": { "start": "2026-08-01T18:00:00.000Z", "end": "2026-08-01T18:00:00.000Z" }
}
```

Create/update requests use **`multipart/form-data`** (not JSON), because they include the image
file. Text fields (`name`, `date`, `description`, `ticketUrl`, and the scheduling fields below)
are sent as form fields alongside an `image` file field.

#### Multi-day and recurring events

`date` is the start of the **first** occurrence.

- **Multi-day** — set `endDate` to when that occurrence finishes. It must be after `date`.
- **Recurring** — set `recurrenceFrequency` to `DAILY`, `WEEKLY` or `MONTHLY` (case-insensitive).
  `recurrenceInterval` (integer, 1–365, default `1`) repeats every N of those units, so
  `WEEKLY` + `2` is fortnightly. `recurrenceEndDate` bounds the series; omit it for an
  open-ended one. Monthly steps clamp to the last day of shorter months (31 Jan → 28 Feb).
  Every occurrence keeps the duration of the first, so a recurring event may also be multi-day
  as long as an occurrence finishes before the next one starts.

Occurrences are **not** stored as separate rows — only the rule is. Each response adds three
read-only derived fields: `isMultiDay`, `isRecurring`, and `nextOccurrence` (`{ start, end }`
of the first occurrence that has not finished yet, or `null` once the event is over).

Because of this, `upcoming` / `past` are decided by `nextOccurrence`, not by `date`: an event
that started yesterday but runs until tomorrow, and a weekly event whose first occurrence was
years ago, are both **upcoming**.

Nullable scheduling fields can be cleared on update by sending them blank (`endDate=`), since
`multipart/form-data` cannot carry a JSON `null`. Clearing `recurrenceFrequency` clears
`recurrenceInterval` and `recurrenceEndDate` with it.

Every event carries a `likeCount`. See [Event likes](#event-likes) for how visitors like and
unlike, and for the `clientId` they identify themselves with.

---

### `GET /api/events`

List all events, ordered by date.

**Query parameters**

| Parameter | Type | Description |
|---|---|---|
| `filter` | string | Optional. `upcoming` → events with `date >= now` (ascending). `past` → events with `date < now` (descending). Omit for all events (ascending). |
| `clientId` | string | Optional. When supplied, each event also carries `likedByMe`. |

**Response** `200 OK`
```json
{ "data": [ { "id": 1, "name": "Eid Dinner", "date": "...", "imageUrl": "...", "description": "...", "ticketUrl": "...", "likeCount": 12 } ] }
```

With `?clientId=...` each event gains `"likedByMe": true | false`.

**Error** `500` — `{ "error": "Failed to fetch events" }`

---

### `GET /api/events/:id`

Fetch a single event by id.

**Query parameters**

| Parameter | Type | Description |
|---|---|---|
| `clientId` | string | Optional. When supplied, the event also carries `likedByMe`. |

**Response** `200 OK`
```json
{ "data": { "id": 1, "name": "Eid Dinner", "date": "...", "imageUrl": "...", "description": "...", "ticketUrl": "...", "likeCount": 12 } }
```

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "Invalid event id" }` |
| `404` | `{ "error": "Event not found" }` |
| `500` | `{ "error": "Failed to fetch event" }` |

---

### `POST /api/events`

Create an event. **Admin only.** `multipart/form-data`.

**Headers**

| Header | Value |
|---|---|
| `Authorization` | `Bearer <access_token>` |

**Form fields**

| Field | Type | Required | Notes |
|---|---|---|---|
| `name` | string | yes | |
| `date` | string | yes | Start of the first occurrence. Any value parseable by `Date` (e.g. ISO 8601 `2026-08-01T18:00:00Z`) |
| `description` | string | yes | |
| `ticketUrl` | string | no | Omit or leave blank if no ticket link |
| `endDate` | string | no | End of that occurrence, for multi-day events. Must be after `date` |
| `recurrenceFrequency` | string | no | `DAILY`, `WEEKLY` or `MONTHLY` (case-insensitive). Omit for a one-off event |
| `recurrenceInterval` | integer | no | Repeat every N units of the frequency. 1–365, defaults to `1`. Requires `recurrenceFrequency` |
| `recurrenceEndDate` | string | no | Last date repeats may fall on. Omit for an open-ended series. Requires `recurrenceFrequency` |
| `image` | file | yes | Image mimetype only, max 5 MB. Uploaded to Supabase Storage. |

**Response** `201 Created`
```json
{ "data": { "id": 1, "name": "Eid Dinner", "date": "...", "imageUrl": "...", "description": "...", "ticketUrl": "..." } }
```

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "name, date and description are required" }` / `{ "error": "An image file is required" }` / any scheduling error below |
| `400` | `{ "error": "date must be a valid date" }` / `{ "error": "endDate must be a valid date" }` / `{ "error": "recurrenceEndDate must be a valid date" }` |
| `400` | `{ "error": "endDate must be after date" }` / `{ "error": "endDate must fall before the next occurrence starts" }` |
| `400` | `{ "error": "recurrenceFrequency must be one of DAILY, WEEKLY, MONTHLY" }` / `{ "error": "recurrenceInterval must be an integer between 1 and 365" }` |
| `400` | `{ "error": "recurrenceEndDate must be on or after date" }` / `{ "error": "recurrenceInterval and recurrenceEndDate require recurrenceFrequency" }` |
| `401` | `{ "error": "Unauthorized" }` |
| `403` | `{ "error": "Forbidden" }` |
| `500` | `{ "error": "Failed to create event" }` |

---

### `PUT /api/events/:id`

Update an event. **Admin only.** `multipart/form-data`. All fields are optional — only the
provided fields are changed. If an `image` file is included, the new image is uploaded and the
old one is removed from storage; otherwise the existing `imageUrl` is kept.

**Headers**

| Header | Value |
|---|---|
| `Authorization` | `Bearer <access_token>` |

**Form fields** — same as `POST`, but all optional (including `image`).

**Response** `200 OK`
```json
{ "data": { "id": 1, "name": "Eid Dinner (updated)", "date": "...", "imageUrl": "...", "description": "...", "ticketUrl": "..." } }
```

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "Invalid event id" }` / any scheduling error listed under `POST` |
| `401` | `{ "error": "Unauthorized" }` |
| `403` | `{ "error": "Forbidden" }` |
| `404` | `{ "error": "Event not found" }` |
| `500` | `{ "error": "Failed to update event" }` |

Scheduling fields are validated against the **stored** event, so sending only `endDate`
is checked against the existing `date`.

---

### `DELETE /api/events/:id`

Delete an event and its stored image. **Admin only.**

**Headers**

| Header | Value |
|---|---|
| `Authorization` | `Bearer <access_token>` |

**Response** `200 OK`
```json
{ "data": { "id": 1 } }
```

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "Invalid event id" }` |
| `401` | `{ "error": "Unauthorized" }` |
| `403` | `{ "error": "Forbidden" }` |
| `404` | `{ "error": "Event not found" }` |
| `500` | `{ "error": "Failed to delete event" }` |

---

## Event likes

Anyone can like an event — no login. Because public visitors are anonymous, the browser
generates a random **`clientId`** once (e.g. `crypto.randomUUID()` kept in `localStorage`) and
sends it with every like request. One like is stored per `(event, clientId)` pair, so a visitor
liking twice does not move the count, and the same id lets them unlike later.

This dedupes honest repeat taps; it is not proof of identity, and someone clearing storage can
like again. That trade-off is deliberate — requiring accounts to like would cost more than the
count is worth.

Both endpoints are **public**, take JSON (or a query string), and reply with the event's fresh
count. Likes are removed automatically when the event is deleted.

---

### `POST /api/events/:id/like`

Like an event. Repeating the call is a no-op, so a retry is safe.

**Body** (`application/json`) — `clientId` may also be sent as a query parameter.

| Field | Type | Required | Notes |
|---|---|---|---|
| `clientId` | string | yes | 1–128 characters. |

**Response** `200 OK`
```json
{ "data": { "id": 1, "likeCount": 13, "likedByMe": true } }
```

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "Invalid event id" }` / `{ "error": "clientId is required" }` |
| `404` | `{ "error": "Event not found" }` |
| `500` | `{ "error": "Failed to like event" }` |

---

### `DELETE /api/events/:id/like`

Remove the caller's like. Succeeds even if they had not liked the event.

**Body** (`application/json`) — same as `POST`. Clients that cannot send a `DELETE` body may
pass `?clientId=...` instead.

**Response** `200 OK`
```json
{ "data": { "id": 1, "likeCount": 12, "likedByMe": false } }
```

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "Invalid event id" }` / `{ "error": "clientId is required" }` |
| `404` | `{ "error": "Event not found" }` |
| `500` | `{ "error": "Failed to unlike event" }` |

---

## Announcements

Announcement data is stored in Postgres (via Prisma). Optional poster images are stored in Supabase Storage (`announcement-images` bucket). Read endpoints are **public**; create/update/delete are **admin-only** (require `Authorization: Bearer <access_token>` with `app_metadata.role === "admin"`).

An announcement has the shape:

```json
{
  "id": 1,
  "title": "Ramadan Reminder",
  "body": "The moon has been sighted. Ramadan starts tomorrow.",
  "pinned": true,
  "imageUrl": "https://<project>.supabase.co/storage/v1/object/public/announcement-images/...",
  "createdAt": "2026-07-25T00:00:00.000Z"
}
```

`imageUrl` is `null` when no image was uploaded.

Create/update requests use **`multipart/form-data`**. Text fields (`title`, `body`, `pinned`) are sent as form fields; `image` is the optional file field.

---

### `GET /api/announcements`

List all announcements. Pinned announcements appear first, then newest-first.

**Response** `200 OK`
```json
{ "data": [ { "id": 1, "title": "...", "body": "...", "pinned": true, "imageUrl": null, "createdAt": "..." } ] }
```

**Error** `500` — `{ "error": "Failed to fetch announcements" }`

---

### `GET /api/announcements/:id`

Fetch a single announcement by id.

**Response** `200 OK`
```json
{ "data": { "id": 1, "title": "...", "body": "...", "pinned": false, "imageUrl": "...", "createdAt": "..." } }
```

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "Invalid announcement id" }` |
| `404` | `{ "error": "Announcement not found" }` |
| `500` | `{ "error": "Failed to fetch announcement" }` |

---

### `POST /api/announcements`

Create an announcement. **Admin only.** `multipart/form-data`.

**Headers**

| Header | Value |
|---|---|
| `Authorization` | `Bearer <access_token>` |

**Form fields**

| Field | Type | Required | Notes |
|---|---|---|---|
| `title` | string | yes | Short heading |
| `body` | string | yes | Full announcement text |
| `pinned` | boolean | no | `"true"` or `"false"` (string); defaults to `false` |
| `image` | file | no | Image mimetype only, max 5 MB. Uploaded to Supabase Storage. |

**Response** `201 Created`
```json
{ "data": { "id": 1, "title": "...", "body": "...", "pinned": false, "imageUrl": null, "createdAt": "..." } }
```

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "title and body are required" }` |
| `401` | `{ "error": "Unauthorized" }` |
| `403` | `{ "error": "Forbidden" }` |
| `500` | `{ "error": "Failed to create announcement" }` |

---

### `PUT /api/announcements/:id`

Update an announcement. **Admin only.** `multipart/form-data`. All fields are optional — only the provided fields are changed. If an `image` file is included, the new image is uploaded and the old one is removed from storage; otherwise the existing `imageUrl` is kept.

**Headers**

| Header | Value |
|---|---|
| `Authorization` | `Bearer <access_token>` |

**Form fields** — same as `POST`, but all optional (including `image`).

**Response** `200 OK`
```json
{ "data": { "id": 1, "title": "...", "body": "...", "pinned": true, "imageUrl": "...", "createdAt": "..." } }
```

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "Invalid announcement id" }` |
| `401` | `{ "error": "Unauthorized" }` |
| `403` | `{ "error": "Forbidden" }` |
| `404` | `{ "error": "Announcement not found" }` |
| `500` | `{ "error": "Failed to update announcement" }` |

---

### `DELETE /api/announcements/:id`

Delete an announcement and its stored image (if any). **Admin only.**

**Headers**

| Header | Value |
|---|---|
| `Authorization` | `Bearer <access_token>` |

**Response** `200 OK`
```json
{ "data": { "id": 1 } }
```

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "Invalid announcement id" }` |
| `401` | `{ "error": "Unauthorized" }` |
| `403` | `{ "error": "Forbidden" }` |
| `404` | `{ "error": "Announcement not found" }` |

---

## Flagship Events

A flagship event is a marketing landing page at `/<slug>/` (e.g. `/sacred-union/`) with its own ticket page, a home-carousel slide, and admin-managed content/images. Data is stored in Postgres (via Prisma); images are stored in Supabase Storage (`flagship-images` bucket). Read endpoints are **public**; create/update/delete/upload are **admin-only** (require `Authorization: Bearer <access_token>` with `app_metadata.role === "admin"`).

`released` and `featuredOnHome` are read live by the frontend (the site is a static export, so these flip at runtime without a rebuild) — `GET /api/flagship-events` always returns every row, released or not, and the frontend decides what to show.

A flagship event has the shape:

```json
{
  "id": 1,
  "slug": "sacred-union",
  "name": "The Sacred Union",
  "tagline": "Prepare for the future you pray for",
  "description": "...",
  "phase": "save-the-date",
  "featuredOnHome": true,
  "released": false,
  "ticketUrl": "",
  "ticketEventId": "1662679",
  "start": "2026-11-28T13:30:00.000Z",
  "end": "2026-11-28T19:30:00.000Z",
  "dateLabel": "Saturday 28 November 2026",
  "timeLabel": "1:30 pm – 7:30 pm",
  "venue": {
    "name": "RMIT Storey Hall",
    "address": "...",
    "mapUrl": "...",
    "notes": ["..."],
    "image": { "src": "...", "alt": "...", "width": 1024, "height": 576 }
  },
  "banner": { "src": "...", "alt": "...", "width": 1600, "height": 900, "mobile": { "src": "...", "width": 1290, "height": 2796 } },
  "ogImage": "...",
  "theme": {
    "dark": "#5B0B05", "onDark": "#EAE3D8", "light": "#EAE3D8", "onLight": "#561610",
    "primary": "#D43325", "onPrimary": "#FFFFFF", "accent": "#509589",
    "hero": { "backdrop": "...", "backdropMobile": "...", "background": "...", "text": "#561610", "heading": "#561610" }
  },
  "highlights": [{ "title": "...", "body": "..." }],
  "speakers": [{ "name": "...", "title": "...", "topic": "...", "image": "..." }],
  "speakerPlaceholderCount": 3,
  "programme": [{ "time": "...", "title": "...", "detail": "..." }],
  "faqs": [{ "question": "...", "answer": "..." }],
  "createdAt": "...",
  "updatedAt": "..."
}
```

`phase` is one of `"save-the-date"` | `"booking"`. `venue.image`, `banner.mobile` and `theme.hero.backdropMobile` are optional. `speakers`, `highlights`, `programme`, `faqs` default to `[]`.

`POST`/`PUT` take a **JSON** body with the full shape above (unlike `Event`/`Announcement`, a flagship event has too many images for one multipart request) — upload each image first via `POST /api/flagship-events/upload-image` and put the returned URL in the relevant field before saving.

---

### `GET /api/flagship-events`

List all flagship events, ordered by `start` ascending.

**Response** `200 OK`
```json
{ "data": [ { "id": 1, "slug": "sacred-union", "...": "..." } ] }
```

**Error** `500` — `{ "error": "Failed to fetch flagship events" }`

---

### `GET /api/flagship-events/:slug`

Fetch a single flagship event by slug.

**Response** `200 OK`
```json
{ "data": { "id": 1, "slug": "sacred-union", "...": "..." } }
```

**Error** `404` — `{ "error": "Flagship event not found" }`

---

### `POST /api/flagship-events/upload-image`

Upload one image and get back its Storage URL. **Admin only.** `multipart/form-data`.

**Headers**

| Header | Value |
|---|---|
| `Authorization` | `Bearer <access_token>` |

**Form fields**

| Field | Type | Required | Notes |
|---|---|---|---|
| `image` | file | yes | Image mimetype only, max 5 MB. |

**Response** `201 Created`
```json
{ "data": { "url": "https://<project>.supabase.co/storage/v1/object/public/flagship-images/..." } }
```

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "An image file is required" }` |
| `401` | `{ "error": "Unauthorized" }` |
| `403` | `{ "error": "Forbidden" }` |
| `500` | `{ "error": "Failed to upload image" }` |

---

### `POST /api/flagship-events`

Create a flagship event. **Admin only.** JSON body — the full shape above, minus `id`/`createdAt`/`updatedAt`. `featuredOnHome`/`released` default to `false`; `ticketUrl`/`ticketEventId` default to `""`; `highlights`/`speakers`/`programme`/`faqs` default to `[]`; `speakerPlaceholderCount` defaults to `0`.

**Headers**

| Header | Value |
|---|---|
| `Authorization` | `Bearer <access_token>` |

**Response** `201 Created` — the created event, same shape as `GET`.

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "<field> is required" }` |
| `400` | `{ "error": "phase must be one of: save-the-date, booking" }` |
| `400` | `{ "error": "A flagship event with that slug already exists" }` |
| `401` | `{ "error": "Unauthorized" }` |
| `403` | `{ "error": "Forbidden" }` |
| `500` | `{ "error": "Failed to create flagship event" }` |

---

### `PUT /api/flagship-events/:id`

Update a flagship event. **Admin only.** JSON body, all fields optional — only the provided fields are changed. Any image URL referenced by the previous version but not the new one is removed from Supabase Storage.

**Headers**

| Header | Value |
|---|---|
| `Authorization` | `Bearer <access_token>` |

**Response** `200 OK` — the updated event, same shape as `GET`.

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "Invalid flagship event id" }` |
| `400` | `{ "error": "phase must be one of: save-the-date, booking" }` |
| `400` | `{ "error": "A flagship event with that slug already exists" }` |
| `401` | `{ "error": "Unauthorized" }` |
| `403` | `{ "error": "Forbidden" }` |
| `404` | `{ "error": "Flagship event not found" }` |
| `500` | `{ "error": "Failed to update flagship event" }` |

---

### `DELETE /api/flagship-events/:id`

Delete a flagship event and every image it referenced. **Admin only.**

**Headers**

| Header | Value |
|---|---|
| `Authorization` | `Bearer <access_token>` |

**Response** `200 OK`
```json
{ "data": { "id": 1 } }
```

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "Invalid flagship event id" }` |
| `401` | `{ "error": "Unauthorized" }` |
| `403` | `{ "error": "Forbidden" }` |
| `404` | `{ "error": "Flagship event not found" }` |

---

## Email Forms

Both form endpoints send mail through [Resend](https://resend.com) and require these environment
variables:

| Variable | Notes |
|---|---|
| `RESEND_API_KEY` | Resend API key |
| `RESEND_FROM_ADDRESS` | Verified sender address mail is sent from |

Each submission triggers **two** emails, sent in parallel:

1. an **inbound** email to `isr@rmit.edu.au`, with `replyTo` set to the submitter's address, and
2. a **confirmation** email back to the submitter.

Only the inbound email is treated as critical — if the confirmation fails, the request still
returns `200` and the failure is logged. All submitted values are HTML-escaped before being
embedded in the email body. When `MOCK_EXTERNALS=1` (e2e / offline local runs) validation still
runs but no mail is sent.

These endpoints are public — no `Authorization` header.

---

### `POST /api/contact`

General contact form submission. `application/json`.

**Body**

| Field | Type | Required | Notes |
|---|---|---|---|
| `name` | string | yes | |
| `email` | string | yes | Must look like an email address |
| `subject` | string | yes | Used as the inbound subject: `[Contact Form] <subject>` |
| `message` | string | yes | Newlines are converted to `<br />` |

```json
{
  "name": "Omar",
  "email": "omar@example.com",
  "subject": "Question about Jumu'ah",
  "message": "Assalamu alaikum, what time does Jumu'ah start?"
}
```

**Response** `200 OK`
```json
{ "success": true }
```

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "name, email, subject, and message are all required" }` / `{ "error": "Invalid email address" }` |
| `500` | `{ "error": "Email service not configured" }` — `RESEND_API_KEY` or `RESEND_FROM_ADDRESS` missing |
| `502` | `{ "error": "Failed to send email" }` — Resend rejected or threw on the inbound email |

---

### `POST /api/sponsorship`

Sponsorship enquiry from a business or organisation, submitted from `/support-us`.
`application/json`.

**Body**

| Field | Type | Required | Notes |
|---|---|---|---|
| `name` | string | yes | Contact person |
| `email` | string | yes | Must look like an email address |
| `phone` | string | yes | Digits, spaces, `(` `)` `.` `-`, optional leading `+`; 6–20 chars |
| `businessType` | string | yes | Free text, e.g. `Restaurant` |
| `businessName` | string | yes | Used as the inbound subject: `[Sponsorship] <businessName>` |
| `message` | string | yes | Newlines are converted to `<br />` |

```json
{
  "name": "Omar",
  "email": "omar@example.com",
  "phone": "+61 400 000 000",
  "businessType": "Restaurant",
  "businessName": "Barakah Eats",
  "message": "We would like to sponsor an ISR event this semester."
}
```

**Response** `200 OK`
```json
{ "success": true }
```

**Errors**

| Status | Body |
|---|---|
| `400` | `{ "error": "name, email, phone, businessType, businessName, and message are all required" }` / `{ "error": "Invalid email address" }` / `{ "error": "Invalid phone number" }` |
| `500` | `{ "error": "Email service not configured" }` — `RESEND_API_KEY` or `RESEND_FROM_ADDRESS` missing |
| `502` | `{ "error": "Failed to send email" }` — Resend rejected or threw on the inbound email |
| `500` | `{ "error": "Failed to delete announcement" }` |