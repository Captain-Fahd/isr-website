import type { MetadataRoute } from 'next'
import { fetchEvents } from '@/lib/events'
import { fetchFlagshipEvents } from '@/lib/flagship'
import { SITE_URL, withTrailingSlash } from '@/lib/seo'

export const dynamic = 'force-static'

function pageEntry(
  path: string,
  lastModified = new Date(),
): MetadataRoute.Sitemap[number] {
  const pathname = path === '/' ? '/' : withTrailingSlash(path)
  return {
    url: `${SITE_URL}${pathname}`,
    lastModified,
  }
}

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  let flagshipEvents: Awaited<ReturnType<typeof fetchFlagshipEvents>> = []
  try {
    flagshipEvents = await fetchFlagshipEvents()
  } catch {
    flagshipEvents = []
  }

  const staticPages = [
    pageEntry('/'),
    pageEntry('/events'),
    pageEntry('/announcements'),
    pageEntry('/about'),
    pageEntry('/history'),
    pageEntry('/operations'),
    pageEntry('/contact'),
    pageEntry('/volunteer'),
    pageEntry('/support-us'),
    pageEntry('/support-us/sponsor'),
    ...flagshipEvents.map(({ slug }) => pageEntry(`/${slug}`)),
    pageEntry('/prayer-times'),
    pageEntry('/privacy'),
  ]

  let eventPages: MetadataRoute.Sitemap = []
  try {
    const events = await fetchEvents('all')
    eventPages = events.map((event) =>
      pageEntry(`/events/${event.id}`, new Date(event.date)),
    )
  } catch {
    eventPages = []
  }

  return [...staticPages, ...eventPages]
}
