export function MailIcon({ className = 'w-6 h-6' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <rect x="3.5" y="5" width="17" height="14" rx="2.5" stroke="currentColor" strokeWidth="1.6" />
      <path d="M5 7l7 5 7-5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export function WhatsappIcon({ className = 'w-6 h-6' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M12 3.5A8.5 8.5 0 0 0 4.1 15.1L3.5 20.5l5.4-.6A8.5 8.5 0 1 0 12 3.5z" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M9.5 8.8c.2-.4.4-.5.7-.5h.7c.2 0 .4.1.5.4l.8 1.9c.1.2 0 .4-.1.6l-.4.5c-.1.1-.1.3 0 .5.3.6.9 1.4 1.8 2 .2.1.3.1.5 0l.7-.4c.2-.1.4-.1.6 0l1.8.8c.2.1.3.3.3.5v.7c0 .3-.1.5-.4.7-.4.2-.9.4-1.4.4-3.1 0-6.8-3.7-6.8-6.8 0-.5.1-1 .4-1.4z" fill="currentColor" />
    </svg>
  )
}

export function InstagramIcon({ className = 'w-6 h-6' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <rect x="3.5" y="3.5" width="17" height="17" rx="4.5" stroke="currentColor" strokeWidth="1.6" />
      <circle cx="12" cy="12" r="4.1" stroke="currentColor" strokeWidth="1.6" />
      <circle cx="17.2" cy="6.8" r="1" fill="currentColor" />
    </svg>
  )
}

export function LocationIcon({ className = 'w-5 h-5' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M12 21s7-4.5 7-10A7 7 0 1 0 5 11c0 5.5 7 10 7 10z" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="12" cy="10" r="2" fill="currentColor" />
    </svg>
  )
}

export function ArrowRight({ className = 'w-4 h-4 inline-block ml-2' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M5 12h14M13 5l6 7-6 7" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

export function CommunityIcon({ className = 'w-7 h-7' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <circle cx="9" cy="8.5" r="3.2" stroke="currentColor" strokeWidth="1.5" />
      <path d="M3.5 19.5a5.5 5.5 0 0 1 11 0" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M16.2 5.9a3.2 3.2 0 0 1 0 6.1" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M17 14.6a5.5 5.5 0 0 1 3.5 4.9" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  )
}

export function FaithIcon({ className = 'w-7 h-7' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M15.4 3.6a8.6 8.6 0 1 0 4.2 14.6A7 7 0 0 1 15.4 3.6z"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M18.4 6.1l.85 1.72 1.9.28-1.37 1.34.32 1.89-1.7-.9-1.7.9.33-1.89-1.38-1.34 1.9-.28z"
        fill="currentColor"
      />
    </svg>
  )
}

export function BookIcon({ className = 'w-7 h-7' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path
        d="M12 6.8C10.6 5.5 8.7 4.8 6.6 4.8H3.5v12.6h3.1c2.1 0 4 .7 5.4 2 1.4-1.3 3.3-2 5.4-2h3.1V4.8h-3.1c-2.1 0-4 .7-5.4 2z"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M12 6.8v12.6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  )
}

export function GlobeIcon({ className = 'w-7 h-7' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <circle cx="12" cy="12" r="8.8" stroke="currentColor" strokeWidth="1.5" />
      <path d="M3.4 9.5h17.2M3.4 14.5h17.2" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
      <ellipse cx="12" cy="12" rx="4.2" ry="8.8" stroke="currentColor" strokeWidth="1.3" />
    </svg>
  )
}

export function CoinIcon({ className = 'w-7 h-7' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <circle cx="12" cy="12" r="8.8" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="12" cy="12" r="5.8" stroke="currentColor" strokeWidth="1.2" />
      <path
        d="M12 8.6v6.8M13.9 9.9h-2.7a1.5 1.5 0 000 3h1.6a1.5 1.5 0 010 3h-2.7"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export function PinIcon({ className = 'w-4 h-4' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden>
      <path d="M12 2.5l2.5 5 5.5.8-4 3.9.9 5.5L12 15.3l-4.9 2.4.9-5.5-4-3.9 5.5-.8z" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" fill="currentColor" fillOpacity="0.15" />
      <path d="M12 15.5v6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  )
}

export function HeartIcon({
  className = 'w-5 h-5',
  filled = false,
}: {
  className?: string
  filled?: boolean
}) {
  return (
    <svg
      className={className}
      viewBox="0 0 24 24"
      fill={filled ? 'currentColor' : 'none'}
      aria-hidden
    >
      <path
        d="M12 20.3l-7.1-7a4.5 4.5 0 0 1 6.4-6.3l.7.7.7-.7a4.5 4.5 0 0 1 6.4 6.3l-7.1 7z"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

export function FacebookIcon({ className = 'w-6 h-6' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M14 9h3V6h-3c-1.7 0-3 1.3-3 3v2H9v3h2v7h3v-7h2.2l.8-3H14V9z" />
    </svg>
  )
}

export function LinkedInIcon({ className = 'w-6 h-6' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" aria-hidden>
      <path d="M6.5 9.5H3.7V20h2.8V9.5zM5.1 4A1.65 1.65 0 1 0 5.1 7.3 1.65 1.65 0 0 0 5.1 4zM20.3 20h-2.8v-5.6c0-1.3 0-3-1.8-3s-2.1 1.4-2.1 2.9V20h-2.8V9.5h2.7v1.4h.1c.4-.7 1.3-1.5 2.7-1.5 2.9 0 3.4 1.9 3.4 4.4V20z" />
    </svg>
  )
}
