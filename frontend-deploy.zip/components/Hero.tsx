"use client"

import Link from 'next/link'
import Image from 'next/image'
import PrayerTimesTable from '@/components/PrayerTimesTable'
import { useFlagshipEvents, pickFeaturedFlagshipEvent } from '@/lib/flagship'

const logoClassName =
  'relative z-10 mx-auto h-auto w-[140px] object-contain sm:w-[180px] lg:mx-0'

export default function Hero() {
  const { events } = useFlagshipEvents()
  // Once an admin features+releases a flagship event, its page takes the Volunteer slot.
  const flagship = pickFeaturedFlagshipEvent(events)

  return (
    <section id="hero" className="flex items-center px-4 pb-20 pt-24 max-sm:items-start sm:min-h-screen sm:py-20">
      <div className="container-isr w-full">
        <div className="grid items-center gap-8 sm:gap-12 lg:grid-cols-2 lg:gap-16">
          <div className="mx-auto max-w-xl text-center lg:mx-0 lg:text-left">
            <div className="mb-6 flex justify-center sm:mb-8 lg:justify-start">
              <div className="relative rounded-[28px] bg-white/75 p-3 shadow-[0_16px_36px_rgba(91,11,5,0.08)] ring-1 ring-black/5 backdrop-blur-sm sm:p-4">
                <div className="absolute inset-x-6 top-1/2 h-10 -translate-y-1/2 rounded-full bg-isr-turquoise/10 blur-2xl" />
                <Image
                  src="/images/isr_logo_lightmode.png"
                  alt="ISR logo"
                  width={180}
                  height={120}
                  className={logoClassName}
                  priority
                />
              </div>
            </div>

            <h1 className="mb-4 text-3xl font-bold text-isr-dark-red sm:text-4xl md:text-5xl lg:text-6xl">
              Islamic Society of RMIT
            </h1>

            <p className="mb-3 text-lg font-semibold text-isr-dark-red sm:text-xl">
              The Home of Muslim Students at RMIT
            </p>

            <div className="mx-auto flex max-w-sm flex-col gap-3 lg:mx-0">
              <a
                href="https://campus.hellorubric.com/?s=10733"
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-xl bg-isr-turquoise px-8 py-4 text-center text-lg font-semibold text-white shadow-[0_10px_24px_rgba(80,149,137,0.35)] transition-colors hover:bg-isr-dark-red sm:text-xl"
              >
                Join ISR
              </a>
              <div className="grid grid-cols-2 gap-3">
                <Link
                  href={flagship ? `/${flagship.slug}/` : '/volunteer/'}
                  className="rounded-lg border-2 border-isr-bright-red px-4 py-2.5 text-center text-sm font-semibold text-isr-bright-red transition-colors hover:bg-isr-bright-red hover:text-white"
                >
                  {flagship ? flagship.name : 'Volunteer'}
                </Link>
                <Link
                  href="/events/"
                  className="rounded-lg border-2 border-isr-bright-red px-4 py-2.5 text-center text-sm font-semibold text-isr-bright-red transition-colors hover:bg-isr-bright-red hover:text-white"
                >
                  Explore Events
                </Link>
              </div>
            </div>
          </div>

          <div className="mx-auto w-full max-w-md lg:max-w-none">
            <PrayerTimesTable />
          </div>
        </div>
      </div>
    </section>
  )
}
